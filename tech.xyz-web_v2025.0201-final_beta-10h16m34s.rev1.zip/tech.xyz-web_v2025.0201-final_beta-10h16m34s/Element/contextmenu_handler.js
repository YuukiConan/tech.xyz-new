document.addEventListener("DOMContentLoaded", () => {
    const ctxMenu = document.getElementById("ctxmenu");
    
    document.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        ctxMenu.style.animation = 'none';
    
        const { clientX: mouseX, clientY: mouseY } = event;
        ctxMenu.style.top = `${mouseY}px`;
        ctxMenu.style.left = `${mouseX}px`;
        ctxMenu.style.display = 'block';
        requestAnimationFrame(() => {
            ctxMenu.style.animation = 'fadeInDown .4s cubic-bezier(0.075, 0.82, 0.165, 1)';
        });
    });
    
    document.addEventListener("click", () => {
        ctxMenu.style.animation = "fadeOutDown .4s cubic-bezier(0.175, 0.885, 0.32, 1.275)";

        ctxMenu.addEventListener("animationend", () => {
            if (ctxMenu.style.animation.includes("fadeOutDown")) {
                ctxMenu.style.display = 'none';
            }
        }, { once: true });
    });
})