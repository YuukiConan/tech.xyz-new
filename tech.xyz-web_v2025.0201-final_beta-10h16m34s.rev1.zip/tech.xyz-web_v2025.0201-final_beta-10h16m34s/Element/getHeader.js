document.addEventListener("DOMContentLoaded", (event) => {
    fetch("Element/header.html") 
    .then(response => response.text())
    .then(data => {
        let header = document.querySelector('header');
        header.innerHTML = data;
        event.preventDefault();
        
        const hash = window.location.hash;
        function showTab(tab) {
            history.scrollRestoration = 'manual';
            const tabs =  document.querySelectorAll('.tab-panel');
            const buttons = document.querySelectorAll('.side-button');
    
            tabs.forEach(tab => tab.classList.remove('active'));
    
            buttons.forEach(button => button.classList.remove('active'));
    
            document.getElementById(tab).classList.add('active');
    
            document.querySelector(`#${tab}-tab`).classList.add('active');
        }
        
        window.addEventListener('hashchange', () => {
            const tab = hash.replace('#', '') || 'home';
            showTab(tab);
        })
        
        const cbx = document.querySelector("#checkbox");
        const useDaylightModeCbx = document.getElementById('useDaylightMode');
        const li_darkmode = document.getElementById('menu-darkmode');
        const saveCheckState = localStorage.getItem("checked") === "true"; 
        const darkMode = localStorage.getItem("darkMode") === "true";
        let intervalId;

        if (darkMode) {
            document.body.classList.add("dark-mode");
            cbx.checked = true;
            setDarkMode(true);
        }
        
        function setDarkMode(enabled) {
            if (enabled) {
                document.body.classList.add("dark-mode");
                localStorage.setItem("darkMode", "true");
            }
            else {
                document.body.classList.remove("dark-mode");
                localStorage.setItem("darkMode", "false");
            }

            cbx.checked = enabled;
        }

        function checkUpdateMode() {
            const time =  new Date();
            let hour = time.getHours();
            const isNight = hour >= 18 || hour < 7;

            setDarkMode(isNight);
        }

        // Function to precise the theme change interval
        function preciseInterval() {
            const now = new Date();
            const secToNextMin = 60 - now.getSeconds();

            setTimeout(() => {
                checkUpdateMode();
                intervalId = setInterval(checkUpdateMode, 50 * 60);
            }, secToNextMin * 10)
        }

        cbx.addEventListener("change", () => {
            if (!useDaylightModeCbx.checked) {
                cbx.disabled = true;

                setTimeout(() => {
                    setDarkMode(cbx.checked);
                    cbx.disabled = false;
                }, 500)
            }
        });

        if (saveCheckState) {
            li_darkmode.classList.add("disabled");
            useDaylightModeCbx.checked = true;

            if (!intervalId) {
                preciseInterval();
            }
        }

        useDaylightModeCbx.addEventListener("change", () => {
            if (useDaylightModeCbx.checked) {
                li_darkmode.classList.add('disabled');
                cbx.classList.add('disabled');
                cbx.disabled = true;
                localStorage.setItem("checked", "true");

                if (!intervalId) {
                    preciseInterval();
                }

                checkUpdateMode();
            } else {
                li_darkmode.classList.remove('disabled');
                cbx.classList.remove('disabled');
                cbx.disabled = false;
                localStorage.setItem("checked", "false");

                if (intervalId) {
                    clearInterval(intervalId);
                    intervalId = null;
                }

                checkUpdateMode();
            }
        });


        function updateClock() {
            let clock = document.getElementById('clock');
            let date = new Date();
            let hours = String(date.getHours()).padStart(2, '0');
            let min = String(date.getMinutes()).padStart(2, '0');
            clock.innerText = `${hours}:${min}`;
        }

        setInterval(updateClock, 1000);

        const amoledCbx = document.getElementById('amoledEnabled');
        const amoledState = localStorage.getItem('amoled-switch') === 'enabled';
        const isAmoledEnabled = localStorage.getItem('amoled-mode') === 'enabled';
        function setAmoled(enabled) {
            if (enabled) {
                document.body.classList.add('amoled');
                localStorage.setItem("amoled-mode", "enabled");
            } else {
                document.body.classList.remove('amoled');
                localStorage.setItem("amoled-mode", "disabled");
            }

            amoledCbx.checked = enabled;
        }


        if (isAmoledEnabled) {
            document.body.classList.add('amoled');
            amoledCbx.checked = true;
            li_darkmode.classList.add("disabled");
            useDaylightModeCbx.disabled = true;
            setAmoled(true);
        }
        
        if (amoledState) {
            amoledCbx.checked = true;
        }

        amoledCbx.addEventListener('change', () => {
            if (amoledCbx.checked) {
                document.body.classList.add('amoled');
                amoledCbx.checked = true;
                li_darkmode.classList.add("disabled");
                cbx.disabled = true;
                useDaylightModeCbx.disabled = true;
                localStorage.setItem("amoled-mode", "enabled");
            }
            else {
                document.body.classList.remove('amoled');
                amoledCbx.checked = false;
                li_darkmode.classList.remove("disabled");
                cbx.disabled = false;
                useDaylightModeCbx.disabled = false;
                localStorage.setItem("amoled-mode", "disabled");
            }
        })

        const dsbanimCbx = document.getElementById('dsbanimCbx');
        const animState = localStorage.getItem('anim-switch') === 'enabled';
        const isAnimEnabled = localStorage.getItem('anim-mode') === 'enabled';

        function setAnim(enabled) {
            if (enabled) {
                document.body.classList.add('anim-disabled');
                localStorage.setItem("anim-mode", "enabled");
            } else {
                document.body.classList.remove('anim-disabled');
                localStorage.setItem("anim-mode", "disabled");
            }

            dsbanimCbx.checked = enabled;
        }

        if (isAnimEnabled) {
            document.body.classList.add('anim-disabled');
            dsbanimCbx.checked = true;
            setAnim(true);
        }
        
        if (animState) {
            dsbanimCbx.checked = true;
        }

        dsbanimCbx.addEventListener('change', () => {
            if (dsbanimCbx.checked) {
                document.body.classList.add('anim-disabled');
                dsbanimCbx.checked = true;
                localStorage.setItem("anim-mode", "enabled");
            }
            else {
                document.body.classList.remove('anim-disabled');
                dsbanimCbx.checked = false;
                localStorage.setItem("anim-mode", "disabled");
            }
        })

        const del = document.getElementById("delete-notify");
        const modal = document.querySelector('.modal');
        const modalOverlay = document.querySelector('.overlay');
        
        del.addEventListener('click', (event) => {
            if (event.target.matches('.modal')) {
                modal.classList.add('close');
                setTimeout(() => {
                    modal.classList.add('hidden');
                }, 100);
            }
            del.addEventListener("click", () => {
                modal.classList.remove('close')
                modal.classList.remove("hidden");
            })
    
            document.getElementById('ok').addEventListener('click', () => {
                modal.classList.add('close');
                setTimeout(() => {
                    modal.classList.add("hidden")
                }, 100)
            });
            document.getElementById('cancel').addEventListener('click', () => {
                modal.classList.add('close');
                setTimeout(() => {
                    modal.classList.add("hidden")
                }, 100)
            });
            modalOverlay.addEventListener('click', () => {
                modal.classList.add('close');
                setTimeout(() => {
                    modal.classList.add('hidden');
                }, 100);
            });
        });

        let currentPage = 0;

        // Memanggil semua elemen dengan class "back-btn" lalu menyisipkan kode HTML untuk menambahkan ikon panah ke kiri tanpa harus menambahkan ke file HTML tiap tombol.
        const back_btn = document.querySelectorAll(".back-btn");
        back_btn.forEach(allback_btn => {
            allback_btn.innerHTML = `<i class="uil uil-arrow-left"></i>`;
        })

        const dropdown_btn = document.getElementById("dropdown-btn");
        const dropdowns = document.querySelectorAll(".dropdown-content");
        const searchDropDown = document.querySelectorAll(".search-content");
        const windowDropDown = document.querySelectorAll(".window-content");
        const navMenu = document.getElementById("navigationMenu");
        const search_btn = document.getElementById("search-click");
        const searchMenu = document.getElementById("searchMenu");
        const window_btn = document.getElementById("window-btn");
        const windowMenu = document.getElementById("windowMenu");
        const overlay = document.querySelector('.overlay');
        const searchBoxAlts = document.querySelectorAll('.searchBox-alt');
        
        function showIndexPage(page) {
            document.querySelector(".index-" + currentPage).classList.remove("act");
            currentPage = page;
            document.querySelector(".index-" + currentPage).classList.add("act");
        }
        function backtoMain() {
            document.querySelector('.index-' + currentPage).classList.remove('act');
            currentPage = 0;
            document.querySelector('.index-' + currentPage).classList.add('act');
        }

        document.addEventListener("click", (event) => {
            const menuButton = event.target.closest(".menuButton");

            if (event.target.closest(".back-btn")) {
                backtoMain();
                if ('scrollRestoration' in history) {
                    history.scrollRestoration = 'manual';
                }
                navMenu.scrollTo(0,0);
            }

            if (menuButton) {
                const targetPage = menuButton.getAttribute("data-target");
                // Tentukan indeks halaman berdasarkan data-target (misalnya "index1", "index2")
                if (event.currentTarget.contains(event.target)) {
                    if (targetPage === "index1") {
                        showIndexPage(1);
                        navMenu.scrollTo(0,0);
                    } else if (targetPage === "index2") {
                        showIndexPage(2);
                        navMenu.scrollTo(0,0);
                    } else if (targetPage === "index3") {
                        showIndexPage(3);
                        navMenu.scrollTo(0,0);
                    }
                }
            }
        });

        let scrollPosition;
        scrollPosition = window.scrollY;

        dropdown_btn.addEventListener("click", (event) => {
            event.stopPropagation();
            navMenu.classList.toggle("show");
            navMenu.classList.remove("hidden");
            document.body.style.top = `-${scrollPosition}px`;
            navMenu.scrollTo(0,0);
            document.body.classList.add('disableScroll');
            setTimeout(() => {
                overlay.classList.toggle("showOverlay");
            }, 100)
        });
        
        search_btn.addEventListener("click", (event) => {
            event.stopPropagation();
            searchMenu.classList.toggle("show");
            searchMenu.classList.remove("hidden");
            document.body.style.top = `-${scrollPosition}px`;
            document.body.classList.add('disableScroll');
            setTimeout(() => {
                overlay.classList.toggle("showOverlay");
            }, 100)
        });

        window_btn.addEventListener("click", (event) => {
            event.stopPropagation();
            windowMenu.classList.toggle("show");
            windowMenu.classList.remove("hidden");
            document.body.style.top = `-${scrollPosition}px`;
            document.body.classList.add('disableScroll');
            setTimeout(() => {
                overlay.classList.toggle("showOverlay");
            }, 100)
            setTimeout(() => {
                document.getElementById('windowplus').classList.remove('hidden');
            }, 2000)
        });

        window.addEventListener('click', (event) => {
            if (!event.target.matches('#dropdown-button') && !event.target.matches('#dropdown-button i') && !event.target.matches('.dropdown-content *')) {
                for (const opendrop of dropdowns) {
                    if (opendrop.classList.contains('show')) {
                        opendrop.classList.remove('show');
                        setTimeout(() => {
                            navMenu.classList.toggle("hidden");
                            
                            if (currentPage >= 1) {
                                showIndexPage(0);
                                navMenu.scrollTo(0,0);
                            }
                            overlay.classList.toggle("showOverlay");
                            document.body.style.top = '';
                            document.body.classList.remove('disableScroll');
                        }, 100);
                        searchBoxAlts.forEach(notifySearchBox => {
                           notifySearchBox.value = '';
                        });
                    } else {
                        if (currentPage !== 0) {
                            showIndexPage(0);
                            navMenu.scrollTo(0,0);
                        }
                    }
                }
            }
            if (!event.target.matches('#search-click') && !event.target.matches('#search-click i') && !event.target.matches('.search-content *')) {
                for (const opendrop of searchDropDown) {
                    if (opendrop.classList.contains('show')) {
                        opendrop.classList.remove('show');
                        setTimeout(() => {
                            searchMenu.classList.add("hidden")
                            overlay.classList.toggle("showOverlay");
                            searchBoxAlts.forEach(searchBoxClickAlt => {
                                searchBoxClickAlt.value = '';
                            });
                            document.body.style.top = '';
                            document.body.classList.remove('disableScroll');
                        }, 100);
                    }
                }
            }
            if (!event.target.matches('#window-btn') && !event.target.matches('#window-btn i') && !event.target.matches('.window-content *')) {
                for (const opendrop of windowDropDown) {
                    if (opendrop.classList.contains('show')) {
                        opendrop.classList.remove('show');
                        setTimeout(() => {
                            windowMenu.classList.add("hidden")
                            overlay.classList.toggle("showOverlay");
                            document.body.style.top = '';
                            document.body.classList.remove('disableScroll');
                        }, 100);
                    }
                }
            }
        });
        
        var acc_username = document.getElementById('account-username');
        var header_username = document.getElementById('nav-current-username');
        
        function adjustUsername() {
            // Synchronize username on the header with the username in account-panel one.
            // const maxCharsSmall = 10;
            // const maxCharsMid = 20;
            // const maxCharsLarge = 30;
            if (acc_username && header_username) {
                let accpanelUserName = acc_username.innerText.trim();
                header_username.innerText = accpanelUserName.split(" ")[0];
                
                // if (window.innerWidth < 600) {
                //     header_username.innerText = accpanelUserName.length > maxCharsSmall 
                //     ? accpanelUserName.substring(0, maxCharsSmall) + ' ' 
                //     : accpanelUserName;
                // } else if (window.innerWidth < 1100) {
                //     header_username.innerText = accpanelUserName.length > maxCharsMid 
                //     ? accpanelUserName.substring(0, maxCharsMid) + ' ' 
                //     : accpanelUserName;
                // } else {
                //     header_username.innerText = accpanelUserName.length > maxCharsLarge 
                //         ? accpanelUserName.substring(0, maxCharsLarge) + '...' 
                //         : accpanelUserName;
                // }
            }
        }
        adjustUsername();
        window.addEventListener('resize', adjustUsername);

        window.addEventListener("scroll", (event) => {
            event.preventDefault();
            const progbarPage = document.getElementById('progbar-page');

            const windowY = window.scrollY;
            const clientHeight = document.documentElement.clientHeight;
            const scrollHeight = document.documentElement.scrollHeight;

            const scrollPercentage = (windowY / (scrollHeight - clientHeight)) * 100;

            progbarPage.style.width = `${scrollPercentage}%`;
        });
    })
    .catch(error => console.error("Error fetching header:", error));
});
