document.addEventListener('DOMContentLoaded', () => {
    fetch('/Element/header.html')
        .then(response => response.text())
        .then(headerdata => {
            
            document.querySelector('header').innerHTML = headerdata;
            
            window.showTab = showTab;
            
            const hash = window.location.hash;
            
            function showTab(tab) {
                const tabs =  document.querySelectorAll('.tab-panel');
                const buttons = document.querySelectorAll('.side-button');
                
                tabs.forEach(tab => tab.classList.remove('active'));
        
                buttons.forEach(button => button.classList.remove('active'));
        
                document.getElementById(tab).classList.add('active');
        
                document.querySelector(`#${tab}-tab`).classList.add('active');

                const capitalTitle = `${tab}`.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
                document.title = capitalTitle + " - tech.xyz";
                
                if ('scrollRestoration' in history) {
                    history.scrollRestoration = "manual";
                }
                window.scrollTo(0,0);
                
                const allSearchBox = document.querySelectorAll("input[type~='search']");

                // Menghapus teks kotak pencarian di Beranda saat mengganti tab.
                allSearchBox.forEach(searchBox => {
                    searchBox.value = '';
                });
            }

            window.addEventListener('hashchange', () => {
                const tab = hash.replace('#', '') || 'home';
                showTab(tab);
            })
        })
        .catch(headerErr => console.error("Error fetching header:", headerErr));

    
    try {
        history.scrollRestoration = 'manual';

        window.addEventListener('beforeunload', () => {
            document.body.scrollTo(0,0);
        });
        // Mengatur head di seluruh HTML
        function setWebIcon(iconUrl) {
            let link = document.querySelector("link[rel~='icon']");
        
            if (!link) {
                link = document.createElement("link");
                link.rel = "icon";
                document.head.appendChild(link);
            }

            link.href = iconUrl;
        }

        setWebIcon("/icon/tech.xyz-small.png");

        const setDisplay = (element, displayValue) => {
            element.style.display = displayValue;
        };

        // Loading event
        const bodyContent = document.body;
        const isOnline = window.navigator.onLine;

        setTimeout(() => {
            setDisplay(bodyContent, 'block');
        }, 500)

        let imgs = document.querySelectorAll('img');
        imgs.forEach(img => {
            img.setAttribute('loading', 'lazy');
            img.setAttribute('draggable', 'false');
        })

        const carousel = document.querySelector('.carousel');
        const items = document.querySelectorAll('.carousel-item');
        const prev = document.querySelector('.modern-button.carousel-prev');
        const next = document.querySelector('.modern-button.carousel-next');
        const indicators = document.querySelector('.carousel-indicators');
        const title = document.getElementById("carousel-title");
        const subtitle = document.getElementById('carousel-subtitle')
        let currentIndex = 0;
        let interval;

        items.forEach((_, index) => {
            const indicator = document.createElement('div');
            indicator.dataset.index = index;
            if (index === 0) {
                indicator.classList.add('active');
            }
            indicators.appendChild(indicator);
        });

        const divIndicators = document.querySelectorAll('.carousel-indicators div');

        function goToItem(index) {
            items[currentIndex].classList.remove('active');

            divIndicators[currentIndex].classList.remove('active');
                currentIndex = index;

            items[currentIndex].classList.add('active');

            divIndicators[currentIndex].classList.add('active');
            updateCaptions();
        }

        function updateCaptions() {
            const currentItem = items[currentIndex];
            const dataTitle = currentItem.dataset.title;
            const dataSubtitle = currentItem.dataset.subtitle;
            title.textContent = dataTitle;
            subtitle.textContent = dataSubtitle;
        }

        prev.addEventListener('click', () => {
            goToItem((currentIndex - 1 + items.length) % items.length);
        });

        next.addEventListener('click', () => {
            goToItem((currentIndex + 1) % items.length);
        });

        divIndicators.forEach(indicator => {
            indicator.addEventListener('click', () => {
                goToItem(Number(indicator.dataset.index));
            });
        });

        function enableAutoSlide() {
            interval = setInterval(() => {
                goToItem((currentIndex + 1) % items.length);
            }, 5000);
        }

        function disableAutoSlide() {
            clearInterval(interval);
        }

        carousel.addEventListener('mouseenter', disableAutoSlide);
        carousel.addEventListener('mouseleave', enableAutoSlide);

        enableAutoSlide();

    } catch (error) {
        console.error('An error occurred:', error);
        // Handle the error as needed
    }
});
