document.addEventListener('DOMContentLoaded', async () => {
    fetch('/Element/header.html')
        .then(response => response.text())
        .then(headerdata => {
            document.querySelector('header').innerHTML = headerdata;
        })
        .catch(headerErr => console.error("Error fetching header:", headerErr));

    try {
        history.scrollRestoration = 'manual';

        window.onbeforeunload = () => {
            document.body.scrollTo(0,0);
        }
        // Mengatur head di seluruh HTML
        function setWebIcon(iconUrl) {
            let link = document.querySelector("link[rel~='icon']");
        
            if (!link) {
                link = document.createElement("link");
                link.rel = "icon";
                document.head.appendChild(link);
            }

            link.href = iconUrl;
        }

        setWebIcon("/icon/AI_Rara_New_Logo_20242025__simple.png");

        const setDisplay = (element, displayValue) => {
            element.style.display = displayValue;
        };

        // Loading event
        const loadingContent = document.getElementById("loading-container");
        const bodyContent = document.getElementById("body-content");

        const isOnline = window.navigator.onLine;
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        const executeLoading = async () => {
            if (isOnline) {
                setDisplay(loadingContent, 'none');
                await delay(600);
                setDisplay(bodyContent, 'block');
            }
            else {
                setDisplay(bodyContent, 'none');
                setDisplay(loadingContent, 'none');
            } 
        };

        await executeLoading();

        // Jika Anda melihat galat YCERR-1000 di halaman selain index.html, abaikan saja.
        const cek_hari = document.getElementById('suasana');
        const user_panel = document.getElementById('user-control');

        if (cek_hari) {
            let time = new Date();
            const hours = time.getHours();
    
            if (hours >= 0 || hours < 11) {
                cek_hari.innerHTML = "Selamat pagi";
                user_panel.style.backgroundImage = "linear-gradient(180deg, rgb(255,255,255,0.1),  rgb(255,255,255,0.1), rgb(255,255,255,0.1), rgb(255,255,255,0.1), #0074aa)";
            }
            else if (hours >= 11 || hours < 15) {
                cek_hari.innerHTML = "Selamat siang";
                user_panel.style.backgroundImage = "linear-gradient(180deg, rgb(255,255,255,0.1),  rgb(255,255,255,0.1), rgb(255,255,255,0.1), rgb(255,255,255,0.1), yellow)";
            }
            else if (hours >= 15 || hours < 18) {
                cek_hari.innerHTML = "Selamat sore";
                user_panel.style.backgroundImage = "linear-gradient(180deg, rgb(255,255,255,0.1),  rgb(255,255,255,0.1), rgb(255,255,255,0.1), rgb(255,255,255,0.1), orange)";
            }
            else {
                cek_hari.innerHTML = "Selamat malam";
                user_panel.style.backgroundImage = "linear-gradient(180deg, rgb(255,255,255,0.1), rgb(255,255,255,0.1), rgb(255,255,255,0.1), rgb(255,255,255,0.1), rgb(0, 0, 51)";
            }
    
        } else {
            const currentPage = window.location.pathname.split('/').pop();
            
            if (currentPage !== "index.html" && currentPage !== "") {
                console.clear();
            }
            else {
                console.error("YCERR-100: Gagal mengambil hari.")
            }
        }

        let imgs = document.querySelectorAll('img');
        imgs.forEach(img => {
            img.setAttribute('loading', 'lazy');
            img.setAttribute('draggable', 'false');
        })
    } catch (error) {
        console.error('An error occurred:', error);
        // Handle the error as needed
    }
});
