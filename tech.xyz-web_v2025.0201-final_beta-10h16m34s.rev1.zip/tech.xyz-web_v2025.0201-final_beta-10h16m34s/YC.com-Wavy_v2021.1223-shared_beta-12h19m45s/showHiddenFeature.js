document.addEventListener("DOMContentLoaded", () => {
    try {
        window.actFeature = actFeature;
        window.deactivateFeature = deactivateFeature;
        window.checkFeatureStatus = checkFeatureStatus;

        // Fungsi untuk mengaktifkan fitur tersembunyi
        function actFeature() {
            const command = document.getElementById("text-command").value.trim();
            const beta = document.querySelectorAll(".featurebeta");
            const allFeatures = JSON.parse(localStorage.getItem("features")) || {};

            if (!command) {
                alert("Silakan masukkan ID fitur.");
                return;
            }

            // Check if the feature IDs are exists in the DOM
            const isFeatureExists = Array.from(beta).some(feature => feature.id === command);
            if (!isFeatureExists) {
                alert(`YCERR-40: Fitur ${command} tidak ditemukan. Silakan coba ID yang lain.`);
                return;
            }
            else {
                try {
                    if (allFeatures[command] === "enabled") {
                        alert(`Fitur ${command} sudah diaktifkan.`);
                    }
                    else {
                        // Tambahkan fitur ke halaman tertentu
                        allFeatures[command] = "enabled";
    
                        // Simpan ke localStorage
                        localStorage.setItem("features", JSON.stringify(allFeatures));
                        alert(`Fitur ${command} berhasil diaktifkan!`);
                    }
                } catch (error) {
                    console.error(`YCERR-40a: Error while activating ID feature ${command}`, error);
                    alert("YCERR-40a: Error while activating feature.");
                }
            }
            checkFeatureStatus(); // Perbarui status fitur
        }

        // Fungsi untuk menonaktifkan fitur tersembunyi
        function deactivateFeature() {
            const command = document.getElementById("text-command").value.trim();
            const beta = document.querySelectorAll(".featurebeta");
            const allFeatures = JSON.parse(localStorage.getItem("features")) || {};

            if (!command) {
                alert("ID fitur tidak valid.");
                return;
            }

            // Check if the feature IDs are exists in the DOM
            const isFeatureExists = Array.from(beta).some(feature => feature.id === command);
            if (!isFeatureExists) {
                alert(`YCERR-40: Fitur ${command} tidak ditemukan. Silakan coba ID yang lain.`);
                return;
            } else {
                try {
                    if (allFeatures[command] === "disabled") {
                        alert(`Fitur ${command} sudah dinonaktifkan.`);
                    } else if (!allFeatures[command]) {
                        alert("ID fitur tidak valid.");
                    }
                    else {
                        allFeatures[command] = "disabled";
                        localStorage.setItem("features", JSON.stringify(allFeatures));
                        alert(`Fitur ${command} berhasil dinonaktifkan!`);
                    }
                } catch (error) {
                    console.error(`YCERR-40b: Error while deactivating ID feature ${command}`, error);
                    alert("YCERR-40b: Error while deactivating feature.");
                }
            }
            checkFeatureStatus();
        }

        function listFeatures() {
            const beta = document.querySelectorAll(".featurebeta");
            const availableFeatures = Array.from(beta).map(feature => feature.id);
            console.log("Available features:", availableFeatures);
        }

        // Fungsi untuk mengecek status fitur di halaman tertentu
        let cachedFeatures = null;
        function checkFeatureStatus() {
            try {
                const allFeatures = JSON.parse(localStorage.getItem("features")) || {};
                console.log("Fitur saat ini:", allFeatures);
                const beta = document.querySelectorAll(".featurebeta");
                console.log("Fitur beta ditemukan:", beta.length);

                beta.forEach(feature => {
                    const id = feature.id.replace("feature-", "");
                    if (allFeatures[id] === "enabled") {
                        feature.classList.remove("hiddenFeature");
                        feature.classList.add("visibleFeature");
                    } else {
                        feature.classList.remove("visibleFeature");
                        feature.classList.add("hiddenFeature");
                    }
                });

                if (JSON.stringify(allFeatures) !== JSON.stringify(cachedFeatures)) {
                    cachedFeatures = {...allFeatures};
                }
            } catch (error) {
                console.error("YCERR-40b: Error checking feature status:", error);
            } finally {
                listFeatures();
            }
        }
    } catch (featureerror) {
        console.log("An error occurred:", featureerror);
    } finally {
        document.addEventListener("DOMContentLoaded", checkFeatureStatus);
    }
});