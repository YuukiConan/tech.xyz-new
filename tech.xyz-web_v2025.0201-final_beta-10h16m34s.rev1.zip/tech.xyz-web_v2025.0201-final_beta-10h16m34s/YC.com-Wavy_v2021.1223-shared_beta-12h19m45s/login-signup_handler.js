document.addEventListener("DOMContentLoaded", () => {
    window.showTab = showTab;

    // Memuat Unicons ke seluruh HTMl.
    let stylesheet = document.querySelector("link[rel~='stylesheet']");
    stylesheet.href = "/styles.css";

    const textpassword = document.getElementById("password");
    const textnewpassword = document.getElementById("new-password");
    const textconfirmnewpassword = document.getElementById("confirm-new-password");
    const showLoginPassBtn = document.querySelector("#showLoginPass");
    const showNewPassBtn = document.querySelector("#showNewPass");
    const showConfirmNewPassBtn = document.querySelector("#showConfirmNewPass");
    
    showLoginPassBtn.addEventListener('click', () => {
        textpassword.type === 'password' ? textpassword.type = 'text' : textpassword.type = 'password';
        showLoginPassBtn.classList.toggle('isToggle');
    });
    showNewPassBtn.addEventListener('click', () => {
        textnewpassword.type === 'password' ? textnewpassword.type = 'text' : textnewpassword.type = 'password';
        showNewPassBtn.classList.toggle('isToggle');
    });
    showConfirmNewPassBtn.addEventListener('click', () => {
        textconfirmnewpassword.type === 'password' ? textconfirmnewpassword.type = 'text' : textconfirmnewpassword.type = 'password';
        showConfirmNewPassBtn.classList.toggle('isToggle');
    });
    
    const hash = window.location.hash;
    function showTab(tab) {
        const tabs =  document.querySelectorAll('.tab-panel');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));

        buttons.forEach(button => button.classList.remove('active'));

        document.getElementById(tab).classList.add('active');

        document.querySelector(`#${tab}-tab`).classList.add('active');

        if (tab === "register") {
            window.location.href = window.location.pathname + "#register";
        } else if (tab === "login") {
            window.location.href = window.location.pathname + "#login";
        } else {
            window.location.href = window.location.pathname + "#developer";
        }

        window.location.hash = '';
        history.replaceState(null, null, `#${tab}`);
    }

    if (hash === "#register") {
        showTab("register");
    } else if (hash === "#developer") {
        showTab("developer")
    } else {
        showTab("login");
    }
});

async function createNewAccount(username, email, password) {
    this.username = username;
    this.email = email;
    this.password = password;

    fetch("/Element/header.html")
        .then(response => {
            if (response.ok) {
                
            } else {
                throw new Error("An error has been occured.");
            }
            return response.text();
        })
        .then (data => {
            JSON.stringify(document.querySelector('header').innerHTML = data);
        })
}

function afterCreateAccount() {
    setTimeout(() => {
        window.location.href = "/index.html";
    }, 1000)
}