YC.com Website
Copyright© 2021 tech.xyz. All rights reserved.
Build: YC.com-Wavy_v2024.1223-shared_beta-12h19m45s
Date: 23 Desember 2024

Developer:
- YuukiC
- HAckerX
- MipMip (Anda tidak akan tahu siapa dia)
- The Sueps (Anda tidak akan tahu siapa mereka)
- VincReal
- BagasBagus
- rikka
- Sara Deon
- Rion Raymond
- Francesca Sarah
- Ruka Sarashina
- Nathania Anneta (Nia)
- Carolina Fanti
- dan 16 lainnya yang tidak disebutkan namanya...

RAHASIA YC.COM:
Versi situs ini tidak ditujukan atau dibagikan untuk publik (alias untuk penguji beta). Segala bentuk publikasi, baik dalam bentuk: screenshot, teks log, atau penyalahgunaan Kebijakan Privasi, dapat dikenakan sanksi sesuai dengan hukum negara masing-masing berdasarkan aturan liabilitas dari YC.com itu sendiri.

--------------------------------------------------------
INFORMASI:

Perubahan penting dari versi v2024.1223-shared_beta-12h19m45s:

1. (BARU!) Logo baru, rasa baru.
2. (BARU!) Halaman Login dan SignUp yang baru.
3. (BARU!) Panel Sekilas di bawah atau samping kontrol pengguna.
4. (BARU!) Untuk pengembang, kami menambahkan tool ID Randomizer yang memungkinkan untuk membuat ID acak dengan rentang 30000000 - 39999999, dan bisa mendaftarkannya ke JSON fitur ID (akan datang).
5. Perubahan gaya besar-besaran pada beberapa elemen.
6. Bilah samping yang sempat dibuat sebagai "placeholder" kini dapat berfungsi dengan baik. Sebagai bagian dari perubahan ini, maka panel akun di bilah navigasi tidak lagi muncul di versi desktop.
7. (BARU!) Legenda Tania dan Jessica ditambahkan!
8. (BARU!) Panel kontrol di halaman dashboard akan berubah warna seiring jam sesuai zona waktu pengguna.

Isu yang diketahui:
1. (KRITIS) Fitur pengaktifan/penonaktifkan elemen tersembunyi mengalami masalah; Bug ini tidak mampu mengaktifkan atau menonaktifkan fitur tersembunyi meskipun ID yang dimasukkan benar. Selain itu, YC.com akan menampilkan "YCERR-40" tentang ID tidak valid meskipun IDnya terdaftar.

Untuk memperbaikinya:
- Pada file "styles.css", cari selector ".hiddenFeature" lalu ubah value properti "display:" dari "none" ke "block".
- Pada Javascript dan Alat Pengembang, cari ID elemen tersembunyi, lalu tulis kode seperti ini:
>> document.getElementById("feature-'your id'").style.display = "block";

Pembuktian: Pada browser versi desktop, tekan F12 pada keyboard atau cari fitur Alat Pengembang atau Developer Tools, lalu pada konsol ketik perintah:
>> JSON.parse(localStorage.getItem("features"));

2. Kami menggunakan workspace/ruang kerja YuukiC untuk pengetesan panel akun baru.
3. Untuk sementara, ID Randomizer hanya akan melakukan generasi nomor acak saja.
4. Anda mungkin mengalami penurunan performa akibat video yang diputar otomatis.

CATATAN:
Beberapa fitur mungkin tidak berfungsi dengan semestinya. Jika Anda ingin melaporkan bug atau usulan fitur, silakan hubungi kami melalui surel: support@yc.com atau melalui halaman Dukungan.
Kami akan merespon Anda secepatnya berdasarkan urgensi yang Anda hadapi.

Terima kasih, dan salam sejahtera untuk pembaca!

--------------------------------------------------------
~ YuukiC from tech.xyz