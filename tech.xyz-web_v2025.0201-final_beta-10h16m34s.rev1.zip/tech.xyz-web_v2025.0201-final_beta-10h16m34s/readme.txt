tech.xyz Website
Copyright© 2025 tech.xyz. All rights reserved.
Build: tech.xyz-web_v2025.0125-shared_beta-10h16m34s
Date: 25 Januari 2025

--------------------------------------------------------
INFORMASI:

Perubahan penting:

1. (BARU!) fitur Window+ (BETA) untuk melakukan multi tugas pada proyek Anda, seperti pemantauan performa, mesin rendering, dan masih banyak lagi! Untuk saat ini, fitur tersebut masih belum berfungsi.
2. (BARU!) Tab Galeri Kami yang merupakan tur mengenai apa yang kami lakukan selama ini untuk Anda dan kenyamanan pengguna lainnya.
3. (BARU!) Desain kartu baru beserta animasi yang menarik.
4. (BARU!) Sekarang Anda dapat melihat READMe di tab Tentang, seperti yang Anda lihat saat ini.
5. (BARU!) Fitur nonaktifkan animasi dan sekarang Anda bisa pilih-pilih tema!
6. Memperbarui warna bilah gulir.
7. Memperbaiki masalah dimana logo di bilah tab mungkin akan naik ke atas saat tinggi jendela dikurangi.
8. Desain Beranda diubah dan menyerupai ke versi final.
9. Ada beberapa foto baru pada kartu di tab Tentang.

Isu yang diketahui:
1. (KRITIS) Fitur pengaktifan/penonaktifkan elemen tersembunyi mengalami masalah; Bug ini tidak mampu mengaktifkan atau menonaktifkan fitur tersembunyi meskipun ID yang dimasukkan benar. Selain itu, YC.com akan menampilkan "YCERR-40" tentang ID tidak valid meskipun IDnya terdaftar.

Untuk memperbaikinya:
- Pada file "styles.css", cari selector ".hiddenFeature" lalu ubah value properti "display:" dari "none" ke "block".
- Pada Javascript dan Alat Pengembang, cari ID elemen tersembunyi, lalu tulis kode seperti ini:
>> document.getElementById("feature-'your id'").style.display = "block";

Pembuktian: Pada browser versi desktop, tekan F12 pada keyboard atau cari fitur Alat Pengembang atau Developer Tools, lalu pada konsol ketik perintah:
>> JSON.parse(localStorage.getItem("features"));

2. Kami menggunakan workspace/ruang kerja YuukiC untuk pengetesan panel akun baru.
3. Untuk sementara, ID Randomizer hanya akan melakukan generasi nomor acak saja.
4. Anda mungkin mengalami penurunan performa akibat video yang diputar otomatis.

CATATAN:
Beberapa fitur mungkin tidak berfungsi dengan semestinya. Jika Anda ingin melaporkan bug atau usulan fitur, silakan hubungi kami melalui surel: support@yc.com atau melalui halaman Dukungan.
Kami akan merespon Anda secepatnya berdasarkan urgensi yang Anda hadapi.

Terima kasih, dan salam sejahtera untuk pembaca!

--------------------------------------------------------
~ YuukiC from tech.xyz